<?php

$validInstallationUrlRewrite = true;

require __DIR__.'/../index.php';
